﻿using CapaLogica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class FrmModuloEspecialista1 : Form
    {
        public FrmModuloEspecialista1()
        {
            InitializeComponent();
        }

        private void MensajeOk(string mensaje)
        {
            MessageBox.Show(mensaje, "Sistema Clínico", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }


        private void Limpiar()
        {
            txtEspecialistaCMP.Clear();
            txtNombreEspecialista.Clear();
            txtApellidoEspecialista.Clear();
            txtCodigoEspecialidad.Clear();
        }

        private void CargarDatosEspecialista()
        {
            try
            {
                dgvEspecialista.DataSource = NEspecialista.ListarEspecialista();
            }
            catch (Exception ex)
            {
                MostrarError("Error al obtener los datos de especialista: " + ex.Message);
            }
        }

        private void BuscarDatosEspecialista()
        {
            dgvEspecialista.DataSource = NEspecialista.ListarEspecialistaCMP(txtEspecialistaCMP.Text);
        }

        private void FrmModuloEspecialista1_Load(object sender, EventArgs e)
        {
            CargarDatosEspecialista();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            BuscarDatosEspecialista();
        }


        private void InsertaModificaEspecialista(bool esInsercion)
        {
            string especialistaCMP = txtEspecialistaCMP.Text.Trim();
            string nombreEspecialista = txtNombreEspecialista.Text.Trim();
            string apellidoEspecialista = txtApellidoEspecialista.Text.Trim();
            string codigoEspecialidad = txtCodigoEspecialidad.Text.Trim();

            if (string.IsNullOrWhiteSpace(especialistaCMP) || string.IsNullOrWhiteSpace(nombreEspecialista) || string.IsNullOrWhiteSpace(apellidoEspecialista))
            {
                MostrarError("Los campos código, nombre y apellido son obligatorios.");
                return;
            }

            string mensaje = esInsercion ? "insertado" : "modificado";
            string metodo = esInsercion ? "Insertar" : "Actualizar";

            string respuesta = esInsercion ? NEspecialista.Insertar(especialistaCMP, nombreEspecialista, apellidoEspecialista, codigoEspecialidad) : NEspecialista.Actualizar(especialistaCMP, nombreEspecialista, apellidoEspecialista, codigoEspecialidad);

            if (respuesta == "Ok")
            {
                MensajeOk($"Especialista {mensaje} exitosamente.");
                Limpiar();
                CargarDatosEspecialista();
            }
            else
            {
                MostrarError($"Error al {metodo} especialista: {respuesta}");
            }
        }







        private void ModificaEspecialista()
        {
            string especialistaCMP = txtEspecialistaCMP.Text.Trim();
            string nombreEspecialista = txtNombreEspecialista.Text.Trim();
            string apellidoEspecialista = txtApellidoEspecialista.Text.Trim();
            string codigoEspecialidad = txtCodigoEspecialidad.Text.Trim();

            // Validación básica (puedes agregar más validaciones)
            if (string.IsNullOrEmpty(especialistaCMP) ||
                string.IsNullOrEmpty(nombreEspecialista) ||
                string.IsNullOrEmpty(apellidoEspecialista))
            {
                MessageBox.Show("Los campos código, nombre y apellido son obligatorios.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertaModificaEspecialista(true);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            InsertaModificaEspecialista(false);
        }


        private void EliminaEspecialista()
        {
            string especialistaCMP = txtEspecialistaCMP.Text.Trim();

            if (string.IsNullOrWhiteSpace(especialistaCMP))
            {
                MostrarError("Debe ingresar el código del especialista a eliminar.");
                return;
            }

            if (MessageBox.Show("¿Está seguro de eliminar el registro?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string respuesta = NEspecialista.Eliminar(especialistaCMP);

                if (respuesta == "Ok")
                {
                    MensajeOk("Registro eliminado exitosamente.");
                    Limpiar();
                    CargarDatosEspecialista();
                }
                else
                {
                    MostrarError($"Error al eliminar registro: {respuesta}");
                }
            }
        }


        private void MostrarError(string mensaje)
        {
            MessageBox.Show(mensaje, "Sistema Clínico", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }



        private void button3_Click(object sender, EventArgs e)
        {
            EliminaEspecialista();
        }
    }
}
