﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace CapaDatos
{
    public class DEspecialista
    {
        private string _EspecialistaCMP;
        public string EspecialistaCMP
        {
            get { return _EspecialistaCMP; }
            set { _EspecialistaCMP = value; }
        }

        private string _EspecialistaNombre;
        public string EspecialistaNombre
        {
            get { return _EspecialistaNombre; }
            set { _EspecialistaNombre = value; }
        }

        private string _EspecialistaApellido;
        public string EspecialistaApellido
        {
            get { return _EspecialistaApellido; }
            set { _EspecialistaApellido = value; }
        }

        private string _EspecialidadCodigo;
        public string EspecialidadCodigo
        {
            get { return _EspecialidadCodigo; }
            set { _EspecialidadCodigo = value; }
        }

        public DEspecialista() { }

        public DEspecialista(string especialistaCMP, string especialistaNombre, string especialistaApellido, string especialidadCodigo)
        {
            this.EspecialistaCMP = especialistaCMP;
            this.EspecialistaNombre = especialistaNombre;
            this.EspecialistaApellido = especialistaApellido;
            this.EspecialidadCodigo = especialidadCodigo;
        }

        public string Insertar(DEspecialista especialista)
        {
            string rpta = "";

            try
            {
                using (SqlConnection sqlCon = new SqlConnection(Conexion.Cn))
                {
                    SqlCommand sqlCmd = new SqlCommand("usp_InsertarEspecialista", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;

                    sqlCmd.Parameters.AddWithValue("@EspecialistaCMP", especialista.EspecialistaCMP);
                    sqlCmd.Parameters.AddWithValue("@EspecialistaNombre", especialista.EspecialistaNombre);
                    sqlCmd.Parameters.AddWithValue("@EspecialistaApellido", especialista.EspecialistaApellido);
                    sqlCmd.Parameters.AddWithValue("@EspecialidadCodigo", especialista.EspecialidadCodigo);

                    sqlCon.Open();
                    rpta = sqlCmd.ExecuteNonQuery() == 1 ? "Ok" : "No se ingresó el registro";
                }
            }
            catch (Exception ex)
            {
                rpta = ex.Message;
            }

            return rpta;
        }

        public string Actualizar(DEspecialista especialista)
        {
            string rpta = "";

            try
            {
                using (SqlConnection sqlCon = new SqlConnection(Conexion.Cn))
                {
                    SqlCommand sqlCmd = new SqlCommand("usp_ActualizarEspecialista", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;

                    sqlCmd.Parameters.AddWithValue("@EspecialistaCMP", especialista.EspecialistaCMP);
                    sqlCmd.Parameters.AddWithValue("@EspecialistaNombre", especialista.EspecialistaNombre);
                    sqlCmd.Parameters.AddWithValue("@EspecialistaApellido", especialista.EspecialistaApellido);
                    sqlCmd.Parameters.AddWithValue("@EspecialidadCodigo", especialista.EspecialidadCodigo);

                    sqlCon.Open();
                    rpta = sqlCmd.ExecuteNonQuery() == 1 ? "Ok" : "No se actualizó el registro";
                }
            }
            catch (Exception ex)
            {
                rpta = ex.Message;
            }

            return rpta;
        }

        public string Eliminar(DEspecialista especialista)
        {
            string rpta = "";

            try
            {
                using (SqlConnection sqlCon = new SqlConnection(Conexion.Cn))
                {
                    SqlCommand sqlCmd = new SqlCommand("usp_EliminarEspecialista", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;

                    sqlCmd.Parameters.AddWithValue("@EspecialistaCMP", especialista.EspecialistaCMP);

                    sqlCon.Open();
                    rpta = sqlCmd.ExecuteNonQuery() == 1 ? "Ok" : "No se eliminó el registro";
                }
            }
            catch (Exception ex)
            {
                rpta = ex.Message;
            }

            return rpta;
        }

        public DataTable ListarEspecialista()
        {
            DataTable dtResultado = new DataTable("Especialista");

            try
            {
                using (SqlConnection sqlCon = new SqlConnection(Conexion.Cn))
                {
                    SqlCommand sqlCmd = new SqlCommand("usp_ListarEspecialista", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter sqlDat = new SqlDataAdapter(sqlCmd);
                    sqlDat.Fill(dtResultado);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al obtener lista de especialistas: " + ex.Message);
                dtResultado = null;
            }

            return dtResultado;
        }

        public DataTable ListarEspecialistaCMP(DEspecialista especialista)
        {
            DataTable dtResultado = new DataTable("Especialista");

            try
            {
                using (SqlConnection sqlCon = new SqlConnection(Conexion.Cn))
                {
                    SqlCommand sqlCmd = new SqlCommand("usp_ListarEspecialistaCMP", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;

                    SqlParameter sqlParam = new SqlParameter("@EspecialistaCMP", SqlDbType.Int)
                    {
                        Value = especialista.EspecialistaCMP
                    };
                    sqlCmd.Parameters.Add(sqlParam);

                    SqlDataAdapter sqlDat = new SqlDataAdapter(sqlCmd);
                    sqlDat.Fill(dtResultado);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al obtener especialista por CMP: " + ex.Message);
                dtResultado = null;
            }

            return dtResultado;
        }
    }
}
