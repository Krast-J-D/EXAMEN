﻿using CapaDatos; // Mantén esta directiva
using System; // Mantén esta directiva
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaLogica
{
    public class NEspecialista
    {
        public static string Insertar(string especialistaCMP, string especialistaNombre, string especialistaApellido, string especialidadCodigo)
        {
            DEspecialista ObjEspecialista = new DEspecialista(especialistaCMP, especialistaNombre, especialistaApellido, especialidadCodigo);
            return ObjEspecialista.Insertar(ObjEspecialista);
        }

        public static string Actualizar(string especialistaCMP, string especialistaNombre, string especialistaApellido, string especialidadCodigo)
        {
            DEspecialista ObjEspecialista = new DEspecialista(especialistaCMP, especialistaNombre, especialistaApellido, especialidadCodigo);
            return ObjEspecialista.Actualizar(ObjEspecialista);
        }

        public static string Eliminar(string especialistaCMP)
        {
            DEspecialista ObjEspecialista = new DEspecialista();
            ObjEspecialista.EspecialistaCMP = especialistaCMP;
            return ObjEspecialista.Eliminar(ObjEspecialista);
        }

        public static DataTable ListarEspecialista()
        {
            return new DEspecialista().ListarEspecialista();
        }

        public static DataTable ListarEspecialistaCMP(string especialistaCMP)
        {
            DEspecialista ObjEspecialista = new DEspecialista();
            ObjEspecialista.EspecialistaCMP = especialistaCMP;
            return ObjEspecialista.ListarEspecialistaCMP(ObjEspecialista);
        }

        private static DEspecialista CrearEspecialista(string especialistaCMP, string especialistaNombre = null, string especialistaApellido = null, string especialidadCodigo = null)
        {
            DEspecialista ObjEspecialista = new DEspecialista();
            ObjEspecialista.EspecialistaCMP = especialistaCMP;
            if (especialistaNombre != null)
                ObjEspecialista.EspecialistaNombre = especialistaNombre;
            if (especialistaApellido != null)
                ObjEspecialista.EspecialistaApellido = especialistaApellido;
            if (especialidadCodigo != null)
                ObjEspecialista.EspecialidadCodigo = especialidadCodigo;
            return ObjEspecialista;
        }
    }
}